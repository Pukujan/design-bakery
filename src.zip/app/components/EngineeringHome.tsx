import { EngineeringHero } from './EngineeringHero';
import { EngineeringProjects } from './EngineeringProjects';
import { EngineeringCommunity } from './EngineeringCommunity';
import { EngineeringAbout } from './EngineeringAbout';
import { EngineeringSkills } from './EngineeringSkills';
import { EngineeringInsights } from './EngineeringInsights';
import { Contact } from './Contact';
import { Footer } from './Footer';

export function EngineeringHome() {
  return (
    <>
      <EngineeringHero />
      <EngineeringProjects />
      <EngineeringCommunity />
      <EngineeringAbout />
      <EngineeringSkills />
      <EngineeringInsights />
      <Contact />
      <Footer />
    </>
  );
}