import { motion } from 'motion/react';
import { Squiggle, Star } from './GraphicElements';
import { Code, Cpu, Layers, Palette } from 'lucide-react';

const skillCategories = [
  {
    title: 'Frontend Engineering',
    icon: Code,
    color: '#4169E1',
    skills: [
      'React',
      'Next.js',
      'TypeScript',
      'TailwindCSS',
      'CSS Architecture',
      'Redux',
      'React Toolkit',
      'GraphQL',
      'REST APIs',
    ],
  },
  {
    title: 'AI & Systems Integration',
    icon: Cpu,
    color: '#9B6DD6',
    skills: [
      'Agentic AI Systems',
      'RAG Pipelines',
      'OpenAI',
      'OpenRouter',
      'Google Gemini',
      'Supabase',
      'PostgreSQL',
      'Vector Databases',
    ],
  },
  {
    title: 'Product & UX Engineering',
    icon: Layers,
    color: '#FF8C42',
    skills: [
      'Complex Form Systems',
      'Validation & Error Handling',
      'PDF & Document Generation',
      'Accessibility (a11y)',
      'Responsive Design',
      'Performance Optimization',
    ],
  },
  {
    title: 'Design (Supporting Skill)',
    icon: Palette,
    color: '#FF6B9D',
    skills: [
      'Figma',
      'Motion Design',
      'Visual Design',
      'Design Systems',
      'Prototyping',
      'User Research',
    ],
  },
];

export function EngineeringSkills() {
  return (
    <section
      id="skills"
      className="py-24 px-6 bg-gradient-to-br from-blue-50 via-purple-50 to-indigo-50 dark:from-blue-950 dark:via-purple-950 dark:to-indigo-950 relative overflow-hidden"
    >
      {/* Decorative elements */}
      <motion.div
        className="absolute top-20 left-1/4"
        animate={{ rotate: 360 }}
        transition={{ duration: 20, repeat: Infinity, ease: 'linear' }}
      >
        <Star color="#4169E1" size={50} />
      </motion.div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-[clamp(3rem,7vw,6rem)] leading-none mb-4 font-black">
            <span className="text-blue-600 dark:text-blue-400">SKILLS</span>{' '}
            <span className="text-purple-600 dark:text-purple-400">&</span>{' '}
            <span className="text-indigo-600 dark:text-indigo-400">
              TECHNOLOGIES
            </span>
          </h2>
          <Squiggle color="#4169E1" className="mx-auto" />
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {skillCategories.map((category, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
              whileHover={{ scale: 1.02 }}
              className="bg-white dark:bg-gray-900 p-8 rounded-3xl border-6 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all"
            >
              <div className="flex items-center gap-4 mb-6">
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
                  style={{ backgroundColor: category.color }}
                >
                  <category.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-2xl md:text-3xl font-black text-gray-900 dark:text-gray-100">
                  {category.title}
                </h3>
              </div>

              <div className="flex flex-wrap gap-3">
                {category.skills.map((skill, sIdx) => (
                  <motion.div
                    key={sIdx}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    viewport={{ once: true }}
                    transition={{
                      delay: idx * 0.1 + sIdx * 0.05,
                      type: 'spring',
                    }}
                    whileHover={{
                      scale: 1.1,
                      rotate: Math.random() * 10 - 5,
                    }}
                  >
                    <div className="px-4 py-2 rounded-full bg-gray-100 dark:bg-gray-800 border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:shadow-[3px_3px_0px_0px_rgba(0,0,0,1)] transition-all">
                      <p className="font-bold text-sm text-gray-900 dark:text-gray-100">
                        {skill}
                      </p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
