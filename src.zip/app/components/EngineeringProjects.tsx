import { motion } from "motion/react";
import {
  ExternalLink,
  Award,
  Users,
  TrendingUp,
  Code2,
  Workflow,
  Database,
  Sparkles,
  Github,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Squiggle, Star } from "./GraphicElements";

const techStack = [
  "React",
  "Next.js",
  "TypeScript",
  "TailwindCSS",
  "PostgreSQL",
  "Node.js",
  "REST APIs",
];

const additionalProjects = [
  {
    id: 2,
    title: "AI Workflow Orchestration",
    description:
      "Agentic AI system for complex task automation and intelligent decision-making, integrated into the product through backend-managed workflows, RAG pipelines, and real-time streaming exposed via frontend interfaces.",
    tech: ["OpenAI", "OpenRouter", "React", "TypeScript"],
    features: [
      "Multi-agent orchestration",
      "RAG pipeline integration",
      "Real-time streaming responses",
    ],
    color: "#9B6DD6",
  },
  {
    id: 3,
    title: "SaaS Dashboard Platform",
    description:
      "Multi-tenant admin system for legal, financial, and business clients with role-based access.",
    tech: [
      "Next.js",
      "PostgreSQL",
      "Redux Toolkit",
      "TailwindCSS",
    ],
    features: [
      "Multi-tenant architecture",
      "Advanced analytics",
      "Role-based permissions",
    ],
    color: "#FF8C42",
  },
];

export function EngineeringProjects() {
  return (
    <section
      id="projects"
      className="py-24 px-6 bg-gradient-to-br from-purple-100 via-blue-100 to-indigo-100 dark:from-purple-950 dark:via-blue-950 dark:to-indigo-950 relative overflow-hidden"
    >
      {/* Decorative elements */}
      <motion.div
        className="absolute top-20 right-1/4"
        animate={{ rotate: 360, y: [0, -20, 0] }}
        transition={{ duration: 15, repeat: Infinity }}
      >
        <Star color="#4169E1" size={50} />
      </motion.div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-[clamp(3rem,7vw,6rem)] leading-none mb-4 font-black">
            <span className="text-blue-600 dark:text-blue-400">
              ENGINEERING
            </span>{" "}
            <span className="text-purple-600 dark:text-purple-400">
              PROJECTS
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-700 dark:text-gray-300 max-w-3xl mx-auto mb-6">
            Systems built for scale, reliability, and real-world
            impact
          </p>
          <Squiggle color="#4169E1" className="mx-auto" />
        </motion.div>

        {/* Featured Project: Ekagajpatra */}
        <motion.div
          id="ekagajpatra"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <Card className="overflow-hidden border-6 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] bg-white dark:bg-gray-900">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Image Side */}
              <div className="relative aspect-[4/3] lg:aspect-auto bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center p-8">
                <div className="relative w-full h-full bg-white/10 backdrop-blur-sm rounded-2xl border-4 border-white/30 shadow-2xl flex items-center justify-center">
                  <ImageWithFallback
                    src="https://www.dropbox.com/scl/fi/2tli5y64sa8avpgm6a320/ekagajpatra-cover.png?rlkey=329kjef4j645gq9hj6dbwb2lr&raw=1
"
                    alt="Ekagajpatra Platform"
                    className="w-full h-full object-cover rounded-xl"
                  />
                </div>
                {/* Featured Badge */}
                <div className="absolute top-6 left-6 bg-yellow-400 px-4 py-2 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <p className="font-black text-black flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    FEATURED PROJECT
                  </p>
                </div>
              </div>

              {/* Content Side */}
              <div className="p-8 lg:p-12">
                <h3 className="text-4xl md:text-5xl font-black mb-4 text-gray-900 dark:text-gray-100">
                  Ekagajpatra
                </h3>
                <p className="text-xl text-blue-600 dark:text-blue-400 mb-6 font-bold">
                  Civic Tech Platform — Design–Engineer
                </p>

                <p className="text-lg text-gray-700 dark:text-gray-300 mb-8 leading-relaxed">
                Architected and built a scalable platform serving 35,000+ users, transforming complex documentation into guided workflows with validation, PDF generation, and multi-role dashboards for citizens and businesses.
                </p>

                {/* Key Achievements */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                  {[
                    {
                      icon: Users,
                      label: "35,000+ Users",
                      color: "#4169E1",
                    },
                    {
                      icon: TrendingUp,
                      label: "99% Cost Reduction",
                      color: "#FF6B9D",
                    },
                    {
                      icon: Award,
                      label: "5 Awards Won",
                      color: "#FFD93D",
                    },
                  ].map((achievement, idx) => (
                    <motion.div
                      key={idx}
                      whileHover={{ scale: 1.05 }}
                      className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 p-4 rounded-2xl border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
                    >
                      <achievement.icon
                        className="w-8 h-8 mb-2"
                        style={{ color: achievement.color }}
                      />
                      <p className="font-bold text-sm text-gray-900 dark:text-gray-100">
                        {achievement.label}
                      </p>
                    </motion.div>
                  ))}
                </div>

                {/* Technical Highlights */}
                <div className="mb-8">
                  <h4 className="text-xl font-bold mb-4 text-gray-900 dark:text-gray-100">
                    Technical Highlights
                  </h4>
                  <div className="space-y-3">
                    {[
                      {
                        icon: Code2,
                        text: "Full-stack Architecture in Next.js, React, TypeScript, Nodejs, PostgreSQL",
                      },
                      {
                        icon: Workflow,
                        text: "Complex multi-step form workflows with real-time validation",
                      },
                      {
                        icon: Database,
                        text: "PDF generation with structured templates and tooltips",
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3"
                      >
                        <item.icon className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                        <p className="text-gray-700 dark:text-gray-300">
                          {item.text}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Tech Stack */}
                <div className="flex flex-wrap gap-2 mb-8">
                  {techStack.map((tech, idx) => (
                    <Badge
                      key={idx}
                      className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] font-bold"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>

                <div className="flex flex-col sm:flex-row flex-wrap gap-4 mb-8">
                  <Button
                    asChild
                    size="lg"
                    className="bg-[#A8CC00] hover:bg-[#8da300] text-black px-8 py-6 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group"
                  >
                    <a
                      href="https://www.ekagajpatra.com"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Visit Live Platform
                      <ExternalLink className="ml-2 h-5 w-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    </a>
                  </Button>

                  <Button
                    asChild
                    size="lg"
                    className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group"
                  >
                    <a
                      href="https://follow-smog-96608767.figma.site"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Full-stack Case Study
                      <ExternalLink className="ml-2 h-5 w-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    </a>
                  </Button>
                </div>

                <p className="text-lg text-gray-700 dark:text-gray-300 mt-8 leading-relaxed">
                  Want a deeper look into frontend architecture
                  and UX decisions?
                </p>

                <Button
                  asChild
                  size="lg"
                  className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-6 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group"
                >
                  <a
                    href="https://mock-flee-81526355.figma.site"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Frontend Engineering Case Study
                    <ExternalLink className="ml-2 h-5 w-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                  </a>
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Project 2: InvestAI */}
        <motion.div
          id="investai"
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7 }}
          className="mb-16"
        >
          <Card className="overflow-hidden border-6 border-black shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] bg-white dark:bg-gray-900">
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Image Side */}
              <div className="relative aspect-[4/3] lg:aspect-auto bg-gradient-to-br from-[#A8CC00] to-green-600 flex items-center justify-center p-8">
                <div className="relative w-full h-full bg-white/10 backdrop-blur-sm rounded-2xl border-4 border-white/30 shadow-2xl flex items-center justify-center">
                  <ImageWithFallback
                    src="https://images.unsplash.com/photo-1761850167081-473019536383?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxmaW5hbmNpYWwlMjB0ZWNobm9sb2d5JTIwZGF0YXxlbnwxfHx8fDE3Njk3MTgxNzl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                    alt="InvestAI Platform"
                    className="w-full h-full object-cover rounded-xl"
                  />
                </div>
                {/* Featured Badge */}
                <div className="absolute top-6 left-6 bg-yellow-400 px-4 py-2 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
                  <p className="font-black text-black flex items-center gap-2">
                    <Sparkles className="w-4 h-4" />
                    AI MVP
                  </p>
                </div>
              </div>

              {/* Content Side */}
              <div className="p-8 lg:p-12">
                <h3 className="text-4xl md:text-5xl font-black mb-4 text-gray-900 dark:text-gray-100">
                  InvestAI
                </h3>
                <p className="text-xl text-[#A8CC00] dark:text-[#A8CC00] mb-6 font-bold shadow-black drop-shadow-sm">
                  AI Systems & Financial Reasoning Platform (MVP)
                </p>

                <p className="text-lg text-gray-700 dark:text-gray-300 mb-8 leading-relaxed">
                  Built a working MVP and actively evolving it into a full-fledged financial learning and credibility evaluation platform, using AI-assisted sentiment and market analysis under real-world cost and system constraints.
                </p>

                {/* Key Achievements */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
                  {[
                    {
                      icon: Users,
                      label: "10+ Experts",
                      color: "#4169E1",
                    },
                    {
                      icon: TrendingUp,
                      label: "Live MVP",
                      color: "#FF6B9D",
                    },
                    {
                      icon: Sparkles,
                      label: "AI Analysis",
                      color: "#FFD93D",
                    },
                  ].map((achievement, idx) => (
                    <motion.div
                      key={idx}
                      whileHover={{ scale: 1.05 }}
                      className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-900 p-4 rounded-2xl border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
                    >
                      <achievement.icon
                        className="w-8 h-8 mb-2"
                        style={{ color: achievement.color }}
                      />
                      <p className="font-bold text-sm text-gray-900 dark:text-gray-100">
                        {achievement.label}
                      </p>
                    </motion.div>
                  ))}
                </div>

                {/* Technical Highlights */}
                <div className="mb-8">
                  <h4 className="text-xl font-bold mb-4 text-gray-900 dark:text-gray-100">
                    Project Highlights
                  </h4>
                  <div className="space-y-3">
                    {[
                      {
                        icon: Code2,
                        text: "Live MVP with public source code available on GitHub",
                      },
                      {
                        icon: Users,
                        text: "Tested by 10+ financial experts across global markets",
                      },
                      {
                        icon: Workflow,
                        text: "Research-driven system design with a clear scalability roadmap",
                      },
                    ].map((item, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3"
                      >
                        <item.icon className="w-5 h-5 text-[#A8CC00] flex-shrink-0 mt-0.5" />
                        <p className="text-gray-700 dark:text-gray-300">
                          {item.text}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Links */}
                <div className="flex flex-col gap-4">
                  <Button
                    asChild
                    size="lg"
                    className="bg-[#A8CC00] hover:bg-[#8da300] text-black px-8 py-6 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group w-full sm:w-auto"
                  >
                    <a
                      href="https://portal-genre-93680338.figma.site"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      View Full Case Study
                      <ExternalLink className="ml-2 h-5 w-5 group-hover:translate-x-1 group-hover:-translate-y-1 transition-transform" />
                    </a>
                  </Button>
                  
                  <div className="flex flex-wrap gap-4">
                    <Button
                      asChild
                      variant="outline"
                      size="lg"
                      className="bg-white dark:bg-gray-800 text-gray-900 dark:text-white px-6 py-4 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group"
                    >
                      <a
                        href="https://financial-investment-with-gemini-in.vercel.app/"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <ExternalLink className="mr-2 h-5 w-5" />
                        Live Demo
                      </a>
                    </Button>
                    
                    <Button
                      asChild
                      variant="outline"
                      size="lg"
                      className="bg-gray-900 text-white px-6 py-4 rounded-full border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] transition-all group"
                    >
                      <a
                        href="https://github.com/Pukujan/financial-investment-with-gemini-insights"
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        <Github className="mr-2 h-5 w-5" />
                        GitHub
                      </a>
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>
        <div className="grid md:grid-cols-2 gap-8">
          {additionalProjects.map((project, idx) => (
            <motion.div
              key={project.id}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
            >
              <Card className="h-full p-8 border-6 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all bg-white dark:bg-gray-900">
                <div
                  className="w-16 h-16 rounded-2xl mb-6 flex items-center justify-center border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
                  style={{ backgroundColor: project.color }}
                >
                  <Code2 className="w-8 h-8 text-white" />
                </div>

                <h3 className="text-3xl font-black mb-3 text-gray-900 dark:text-gray-100">
                  {project.title}
                </h3>
                <p className="text-lg text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                  {project.description}
                </p>

                <div className="mb-6">
                  <h4 className="text-sm font-bold mb-3 text-gray-900 dark:text-gray-100 uppercase tracking-wide">
                    Key Features
                  </h4>
                  <ul className="space-y-2">
                    {project.features.map((feature, fIdx) => (
                      <li
                        key={fIdx}
                        className="flex items-start gap-2"
                      >
                        <div className="w-1.5 h-1.5 rounded-full bg-blue-600 mt-2 flex-shrink-0" />
                        <span className="text-gray-700 dark:text-gray-300">
                          {feature}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech, tIdx) => (
                    <Badge
                      key={tIdx}
                      variant="outline"
                      className="border-2 border-black font-bold"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}