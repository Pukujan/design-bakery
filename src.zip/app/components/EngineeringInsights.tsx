import { motion } from "motion/react";
import {
  ArrowRight,
  Clock,
  Tag,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { Badge } from "./ui/badge";
import { Squiggle } from "./GraphicElements";
import { useState } from "react";
import { Link } from "react-router-dom";

const categories = [
  { id: "all", label: "All Topics", color: "#4169E1" },
  { id: "ai-ml", label: "AI & ML", color: "#9B6DD6" },
  { id: "systems", label: "Systems Design", color: "#FF8C42" },
  {
    id: "product",
    label: "Product Engineering",
    color: "#FF6B9D",
  },
  {
    id: "architecture",
    label: "Architecture",
    color: "#A8CC00",
  },
];

const insights = [
  {
    id: 1,
    title: "Building Scalable Form Systems in Next.js",
    excerpt:
      "How we engineered a multi-step form workflow that handles complex validation, real-time error handling, and maintains state across 15+ screens.",
    date: "January 2026",
    readTime: "8 min read",
    tags: ["Systems Design", "React", "TypeScript"],
    category: "systems",
    color: "#4169E1",
  },
  {
    id: 2,
    title:
      "Agentic AI: Orchestrating Multiple LLMs for Complex Tasks",
    excerpt:
      "Lessons learned building an AI workflow system that coordinates multiple agents, manages context windows, and handles streaming responses.",
    date: "December 2025",
    readTime: "10 min read",
    tags: ["AI", "Product Engineering", "OpenAI"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 3,
    title: "Frontend Architecture for Multi-Tenant SaaS",
    excerpt:
      "Designing a frontend architecture that serves multiple client types while maintaining code reusability, security, and performance.",
    date: "November 2025",
    readTime: "12 min read",
    tags: ["Architecture", "SaaS", "Next.js"],
    category: "architecture",
    color: "#FF8C42",
  },
  {
    id: 4,
    title: "RAG Systems: From Embeddings to Production",
    excerpt:
      "Deep dive into building retrieval-augmented generation systems: vector databases, chunking strategies, hybrid search, and optimizing for accuracy.",
    date: "January 2026",
    readTime: "15 min read",
    tags: ["AI", "RAG", "Vector DB", "LangChain"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 5,
    title: "Fine-Tuning LLMs: When and How",
    excerpt:
      "Practical guide to fine-tuning language models: dataset preparation, evaluation metrics, LoRA vs full fine-tuning, and cost optimization.",
    date: "December 2025",
    readTime: "12 min read",
    tags: ["AI", "Fine-Tuning", "Machine Learning", "OpenAI"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 6,
    title: "Prompt Engineering: Beyond Basic Prompts",
    excerpt:
      "Advanced prompt engineering techniques: chain-of-thought, few-shot learning, prompt chaining, and building reliable AI workflows.",
    date: "November 2025",
    readTime: "10 min read",
    tags: ["AI", "Prompt Engineering", "GPT-4", "Claude"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 7,
    title: "Real-Time Streaming AI Responses in React",
    excerpt:
      "Building responsive AI interfaces with streaming: handling SSE, managing partial responses, and creating smooth UX for LLM applications.",
    date: "October 2025",
    readTime: "8 min read",
    tags: ["AI", "React", "Streaming", "UX"],
    category: "product",
    color: "#FF6B9D",
  },
  {
    id: 8,
    title: "AI Model Evaluation & Testing Strategies",
    excerpt:
      "How to evaluate AI models in production: building test harnesses, measuring accuracy, A/B testing prompts, and monitoring model drift.",
    date: "September 2025",
    readTime: "11 min read",
    tags: ["AI", "Testing", "MLOps", "Evaluation"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 9,
    title: "Context Window Management for Long-Form AI",
    excerpt:
      "Strategies for working with limited context windows: summarization, sliding windows, semantic chunking, and context prioritization.",
    date: "August 2025",
    readTime: "9 min read",
    tags: ["AI", "Context Management", "LLM", "Architecture"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 10,
    title: "Building AI-Native Product Features",
    excerpt:
      "Product thinking for AI: designing features that leverage AI strengths, setting user expectations, and building trust in AI systems.",
    date: "July 2025",
    readTime: "13 min read",
    tags: ["AI", "Product Design", "UX", "Strategy"],
    category: "product",
    color: "#FF6B9D",
  },
  {
    id: 11,
    title: "Multimodal AI: Working with Vision Models",
    excerpt:
      "Integrating vision-language models: image understanding, OCR, diagram analysis, and building multimodal AI applications.",
    date: "June 2025",
    readTime: "14 min read",
    tags: ["AI", "Vision", "Multimodal", "GPT-4V"],
    category: "ai-ml",
    color: "#9B6DD6",
  },
  {
    id: 12,
    title: "Cost Optimization for AI Applications",
    excerpt:
      "Reducing AI costs without sacrificing quality: caching strategies, model selection, token optimization, and infrastructure choices.",
    date: "May 2025",
    readTime: "10 min read",
    tags: [
      "AI",
      "Cost Optimization",
      "Infrastructure",
      "Strategy",
    ],
    category: "product",
    color: "#FF6B9D",
  },
];

const ITEMS_PER_PAGE = 6;

export function EngineeringInsights() {
  const [selectedCategory, setSelectedCategory] =
    useState("all");
  const [currentPage, setCurrentPage] = useState(1);

  // Filter insights by category
  const filteredInsights =
    selectedCategory === "all"
      ? insights
      : insights.filter(
          (insight) => insight.category === selectedCategory,
        );

  // Calculate pagination
  const totalPages = Math.ceil(
    filteredInsights.length / ITEMS_PER_PAGE,
  );
  const startIndex = (currentPage - 1) * ITEMS_PER_PAGE;
  const endIndex = startIndex + ITEMS_PER_PAGE;
  const paginatedInsights = filteredInsights.slice(
    startIndex,
    endIndex,
  );

  // Reset to page 1 when category changes
  const handleCategoryChange = (categoryId: string) => {
    setSelectedCategory(categoryId);
    setCurrentPage(1);
  };

  return (
    <section
      id="insights"
      className="py-24 px-6 bg-gradient-to-br from-purple-100 via-indigo-100 to-blue-100 dark:from-purple-950 dark:via-indigo-950 dark:to-blue-950 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <h2 className="text-[clamp(3rem,7vw,6rem)] leading-none mb-4 font-black">
            <span className="text-purple-600 dark:text-purple-400">
              STUDY
            </span>{" "}
            <span className="text-blue-600 dark:text-blue-400">
              &
            </span>{" "}
            <span className="text-indigo-600 dark:text-indigo-400">
              DOCUMENTATION
            </span>
            <br />
            <span className="text-gray-900 dark:text-gray-100">
              BLOGS
            </span>
          </h2>
          <p className="text-xl text-gray-700 dark:text-gray-300 max-w-2xl mx-auto mb-2">
            Deep technical write-ups, research papers, and
            comprehensive guides
          </p>
          <Squiggle color="#4169E1" className="mx-auto" />
        </motion.div>

        {/* View All Blogs Link */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="text-center pb-10"
        >
          <Link to="/blogs">
            <Button className="px-8 py-4 border-4 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] hover:shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] bg-purple-600 hover:bg-purple-700 text-white font-black text-lg">
              View All
              <ArrowRight className="ml-2 w-5 h-5" />
            </Button>
          </Link>
        </motion.div>
        {/* Category Filter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap justify-center gap-4 mb-12"
        >
          {categories.map((category) => (
            <Button
              key={category.id}
              onClick={() => handleCategoryChange(category.id)}
              className={`
                px-6 py-3 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]
                hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)]
                transition-all font-black text-base
                ${
                  selectedCategory === category.id
                    ? "bg-black text-white"
                    : "bg-white dark:bg-gray-900 text-black dark:text-white hover:bg-gray-50 dark:hover:bg-gray-800"
                }
              `}
              style={{
                borderLeftColor:
                  selectedCategory === category.id
                    ? category.color
                    : undefined,
                borderLeftWidth:
                  selectedCategory === category.id
                    ? "8px"
                    : undefined,
              }}
            >
              {category.label}
            </Button>
          ))}
        </motion.div>

        {/* Insights Grid */}
        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {paginatedInsights.map((insight, idx) => (
            <motion.div
              key={insight.id}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: idx * 0.1 }}
            >
              <Card className="h-full p-6 border-6 border-black shadow-[8px_8px_0px_0px_rgba(0,0,0,1)] hover:shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] transition-all bg-white dark:bg-gray-900 group">
                <div
                  className="w-full h-3 rounded-full mb-6 border-2 border-black"
                  style={{ backgroundColor: insight.color }}
                />

                <div className="flex items-center gap-4 mb-4 text-sm text-gray-600 dark:text-gray-400">
                  <div className="flex items-center gap-1">
                    <Clock className="w-4 h-4" />
                    <span>{insight.readTime}</span>
                  </div>
                  <span>•</span>
                  <span>{insight.date}</span>
                </div>

                <h3 className="text-2xl font-black mb-4 text-gray-900 dark:text-gray-100 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                  {insight.title}
                </h3>

                <p className="text-gray-700 dark:text-gray-300 mb-6 leading-relaxed">
                  {insight.excerpt}
                </p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {insight.tags.map((tag, tIdx) => (
                    <Badge
                      key={tIdx}
                      variant="outline"
                      className="border-2 border-black font-bold text-xs"
                    >
                      <Tag className="w-3 h-3 mr-1" />
                      {tag}
                    </Badge>
                  ))}
                </div>

                <Link to="/blogs">
                  <Button
                    variant="ghost"
                    className="group/btn p-0 h-auto font-bold text-blue-600 dark:text-blue-400 hover:bg-transparent"
                  >
                    Read More
                    <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5 }}
            className="flex items-center justify-center gap-4 mb-8"
          >
            <Button
              onClick={() =>
                setCurrentPage((p) => Math.max(1, p - 1))
              }
              disabled={currentPage === 1}
              className="px-6 py-3 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] bg-white dark:bg-gray-900 text-black dark:text-white disabled:opacity-50 disabled:cursor-not-allowed font-black"
            >
              <ChevronLeft className="w-5 h-5" />
              Previous
            </Button>

            <div className="flex items-center gap-2">
              {Array.from(
                { length: totalPages },
                (_, i) => i + 1,
              ).map((page) => (
                <Button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`
                    w-12 h-12 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]
                    hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] font-black
                    ${
                      currentPage === page
                        ? "bg-black text-white"
                        : "bg-white dark:bg-gray-900 text-black dark:text-white"
                    }
                  `}
                >
                  {page}
                </Button>
              ))}
            </div>

            <Button
              onClick={() =>
                setCurrentPage((p) =>
                  Math.min(totalPages, p + 1),
                )
              }
              disabled={currentPage === totalPages}
              className="px-6 py-3 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] hover:shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] bg-white dark:bg-gray-900 text-black dark:text-white disabled:opacity-50 disabled:cursor-not-allowed font-black"
            >
              Next
              <ChevronRight className="w-5 h-5" />
            </Button>
          </motion.div>
        )}
      </div>
    </section>
  );
}